---
name: Daylight Industrial & Wellness
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444650'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#757682'
  outline-variant: '#c5c6d2'
  surface-tint: '#435b9f'
  primary: '#00113a'
  on-primary: '#ffffff'
  primary-container: '#002366'
  on-primary-container: '#758dd5'
  inverse-primary: '#b3c5ff'
  secondary: '#795900'
  on-secondary: '#ffffff'
  secondary-container: '#ffbf00'
  on-secondary-container: '#6d5000'
  tertiary: '#121516'
  on-tertiary: '#ffffff'
  tertiary-container: '#26292a'
  on-tertiary-container: '#8e9091'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#00174a'
  on-primary-fixed-variant: '#2a4386'
  secondary-fixed: '#ffdfa0'
  secondary-fixed-dim: '#fbbc00'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#e1e3e4'
  tertiary-fixed-dim: '#c5c7c8'
  on-tertiary-fixed: '#191c1d'
  on-tertiary-fixed-variant: '#454748'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
  deep-royal: '#002366'
  vibrant-amber: '#FFBF00'
  charcoal-text: '#1A1A1A'
  divider-gray: '#F8F9FA'
  pure-white: '#FFFFFF'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base-unit: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 80px
  section-gap: 120px
---

## Brand & Style
The design system embodies a "Daylight" aesthetic—a high-end, ultra-modern atmosphere that feels clinical yet organic. It bridges the precision of HVAC engineering with the purity of natural wellness through a style I call **Soft-Precision**.

This style utilizes a "Neo-Brutalism Light" approach: it maintains the structural integrity and clear boundaries of industrial design but softens them with refined typography and subtle glassmorphic overlays. The emotional response is one of absolute reliability, transparency, and premium quality. The UI avoids heavy gradients in favor of flat, confident color blocks and expansive white space to evoke a sense of cleanliness and "fresh air."

## Colors
The palette is rooted in a "Pure White" (#FFFFFF) foundation to represent sterility and clarity. 

- **Deep Royal Blue:** Used for primary branding, navigation, and structural headers to signal industrial authority and trust.
- **Vibrant Amber/Gold:** Reserved exclusively for high-intent Call to Actions (CTAs) and critical highlights. This represents the "warmth" of wellness and the "energy" of the sun.
- **Dark Charcoal:** Used for all body text and headings to ensure maximum legibility and a premium editorial feel.
- **Section Dividers:** We use #F8F9FA for subtle tonal shifts between content blocks, maintaining the high-key "Daylight" environment without needing harsh lines.

## Typography
The typography strategy pairs **Plus Jakarta Sans** for headlines to provide a modern, approachable geometric feel with **Inter** for body copy to maintain a highly functional, industrial legibility.

- **Headlines:** Use tight letter-spacing on larger displays to create a sophisticated "editorial" look.
- **Body:** Inter provides the "utility" required for technical HVAC specifications and supplement ingredient lists.
- **Labels:** Use uppercase with increased tracking for category tags and small metadata to maintain the professional, organized feel of a premium trading firm.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. Content is contained within a 1280px max-width container on desktop, centered with generous 80px margins. 

A strict 8px grid governs all internal component spacing. Section gaps are intentionally large (120px+) to emphasize the "Daylight" concept—letting the design breathe and avoiding the cluttered look often found in industrial catalogs. 

On mobile, the 12-column grid collapses to a 4-column layout with 16px margins. Content reflows vertically, prioritizing high-quality imagery of both machinery and natural spices to balance the brand's dual nature.

## Elevation & Depth
This design system rejects heavy, muddy shadows in favor of **Tonal Layering** and **Glassmorphism**.

1.  **The Base:** Pure White (#FFFFFF).
2.  **The Surface:** For cards and floating elements, use a semi-transparent white (80% opacity) with a 20px backdrop blur (Glassmorphism). This creates a "frosted glass" effect that feels premium and clean.
3.  **The Edge:** Instead of dark shadows, use 1px solid borders in #F8F9FA or #1A1A1A at very low opacity (10%) to define shapes.
4.  **The Focus:** Only use a subtle "Ambient Shadow" (0px 4px 20px rgba(0, 35, 102, 0.05)) for active states or primary cards to provide a hint of lift without breaking the flat aesthetic.

## Shapes
We use a **Soft-Square** (0.25rem) philosophy. This creates a professional, architectural look that feels more precise and "engineered" than fully rounded pill shapes, while still remaining modern.

Large containers and featured images may use `rounded-lg` (0.5rem) to slightly soften the visual impact of high-contrast photography, but the primary interaction elements (buttons, inputs) remain sharp and disciplined.

## Components
- **Buttons:** Primary CTAs use the Vibrant Amber background with Charcoal text for maximum "pop." Secondary buttons are Deep Royal Blue with White text. Use the "Soft" corner radius.
- **Input Fields:** Use a 1px border of #F8F9FA with a Pure White background. On focus, the border transitions to Deep Royal Blue.
- **Cards:** Utilize the Glassmorphism effect described in Elevation. Cards should have no visible shadow in their default state, only a subtle border.
- **Chips/Tags:** Used for product categories (e.g., "HVAC Components" or "Wellness"). These should be flat Deep Royal Blue with White text, or subtle light gray backgrounds with Charcoal text.
- **Lists:** Data-heavy lists (for trading specs) should use alternating row colors in #F8F9FA to maintain horizontal tracking without using heavy lines.
- **Checkboxes/Radios:** Use Deep Royal Blue for selected states to reinforce the industrial-professional brand identity.